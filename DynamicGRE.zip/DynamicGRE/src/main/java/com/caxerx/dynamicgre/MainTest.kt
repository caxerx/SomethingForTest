package com.caxerx.dynamicgre

import com.jcabi.ssh.SSH
import com.jcabi.ssh.Shell
import khttp.get
import java.lang.Thread.sleep
import java.net.URL
import java.util.concurrent.CompletableFuture.runAsync


/**
 * Created by caxerx on 2017/6/4.
 */


fun main(args: Array<String>) {
    var thread = Thread {
        var force: Boolean = true
        val api = CloudflareAPI("3ed7c6f252cbe14aec40b780781ac2fb9836b", "webmaster@caxerx.com", "b262f233872e6634140633c974823a3b")
        val recordName = "ddns.caxerx.com"
        val localSshIp = "192.168.1.120"
        val greIp = "128.199.194.189"
        var nowMyIp = ""
        val key = URL("file:\\\\\\F:\\System_Data\\SystemDesktop\\id_rsa")
        while (true) {
            runAsync {
                var result = checkIpChange(api, recordName)
                nowMyIp = result["ip"]!!
                if (result["changed"]!!.toBoolean() || force) {
                    force = false
                    runAsync {
                        var editResult = editCloudflare(api, recordName, result["ip"]!!)
                        println("cloudflare edit success:" + editResult)
                    }.thenRun {
                        runAsync {
                            editGreTunnel(greIp, nowMyIp, key)
                        }.thenRunAsync {
                            editDestTunnel(greIp, localSshIp, key)
                        }.thenRunAsync {
                            runAsync {
                                pingGreTunnel(greIp, key)
                            }
                            runAsync {
                                pingDestTunnel(localSshIp, key)
                            }
                        }
                    }
                }
            }
            sleep(300000)
        }
    }
    thread.isDaemon = true
    thread.run()
    /*

        /*
    val recordName = "ddns.caxerx.com"
    try {
        var myip = get("http://ipinfo.io/ip").text.trim()
        println("cloudflare: " + api.getRecordContent("ddns.caxerx.com"))
        println("me: $myip")
        if (api.getRecordContent("ddns.caxerx.com").equals(myip, true)) {
            println("sameip,nochange")
        } else {
            println("ip change, update")

            println("cloudflare")
            println(api.editRecordByName("ddns.caxerx.com", "A", myip))
            println("cloudflare done")

            println("ssh_local")

            println("local done")
            println("gre_ext")

            println("gre_ext done")

            println("local ping")
            println(Shell.Plain(localshell).exec("ping 192.168.168.1 -c 1"))
            println("gre_ext ping")
            println(Shell.Plain(greshell).exec("ping 192.168.168.2 -c 1"))

            println("exit ssh")
            Shell.Plain(localshell).exec("exit")
            Shell.Plain(greshell).exec("exit")
            println("everything done")

        }
    } catch(ex: Exception) {
        println("Exception cause")
        ex.printStackTrace()
    }
    sleep(300000)
}
}
*/
*/
}

fun checkIpChange(cloudflareAPI: CloudflareAPI, recordName: String): Map<String, String> {
    var myip = get("https://ifconfig.co/ip").text.trim()
    var cloudflareIp: String = cloudflareAPI.getRecordContent(recordName).trim()
    if (cloudflareIp.equals(myip, true)) {
        println("IP Unchange($myip), nothng do until next cycle")
    } else {
        println("IP Changed($cloudflareIp->$myip), Ready to execute data update")
    }
    var result: HashMap<String, String> = HashMap()
    result.put("old", cloudflareIp)
    result.put("changed", (cloudflareIp.equals(myip, true).not() || myip.equals("")).toString())
    result.put("ip", myip)
    return result
}


fun editCloudflare(cloudflareAPI: CloudflareAPI, recordName: String, newIp: String): Boolean {
    return cloudflareAPI.editRecordByName(recordName, "A", newIp)
}

fun editDestTunnel(greIp: String, sshIp: String, sshKey: URL) {
    //val localip = "192.168.1.120"
    //val greip = "128.199.212.21"
    //val key = URL("file:\\\\\\F:\\System_Data\\SystemDesktop\\id_rsa")
    val localshell = SSH(sshIp, 22, "root", sshKey)
    Shell.Plain(localshell).exec("iptunnel del gre1")
    Shell.Plain(localshell).exec("iptunnel add gre1 mode gre local $sshIp remote $greIp ttl 255")
    Shell.Plain(localshell).exec("ip addr add 192.168.168.2/30 dev gre1")
    Shell.Plain(localshell).exec("ip link set gre1 up")
    Shell.Plain(localshell).exec("ip rule add from 192.168.168.0/30 table GRE")
    Shell.Plain(localshell).exec("ip route add default via 192.168.168.1 table GRE")
    Shell.Plain(localshell).exec("exit")
}

fun editGreTunnel(sshIp: String, destIp: String, sshKey: URL) {
    val greshell = SSH(sshIp, 22, "root", sshKey)
    Shell.Plain(greshell).exec("iptunnel del gre1")
    Shell.Plain(greshell).exec("iptunnel add gre1 mode gre local $sshIp remote $destIp ttl 255")
    Shell.Plain(greshell).exec("ip addr add 192.168.168.1/30 dev gre1")
    Shell.Plain(greshell).exec("ip link set gre1 up")
    Shell.Plain(greshell).exec("iptables -F")
    Shell.Plain(greshell).exec("iptables -t nat -F")
    Shell.Plain(greshell).exec("iptables -t nat -A POSTROUTING -s 192.168.168.0/30 ! -o gre+ -j SNAT --to-source $sshIp")
    Shell.Plain(greshell).exec("iptables -t nat -A PREROUTING -d $sshIp -j DNAT --to-destination 192.168.168.2 -p tcp --dport 25565")
    Shell.Plain(greshell).exec("iptables -t nat -A PREROUTING -d $sshIp -j DNAT --to-destination 192.168.168.2 -p tcp --dport 40000")
    Shell.Plain(greshell).exec("iptables -A FORWARD -d 192.168.168.2 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT -p tcp --dport 25565")
    Shell.Plain(greshell).exec("iptables -A FORWARD -d 192.168.168.2 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT -p tcp --dport 40000")
    Shell.Plain(greshell).exec("exit")

}

fun pingGreTunnel(sshIp: String, sshKey: URL) {
    val greshell = SSH(sshIp, 22, "root", sshKey)
    println(Shell.Plain(greshell).exec("ping 192.168.168.2 -c 1"))
    Shell.Plain(greshell).exec("exit")
}

fun pingDestTunnel(sshIp: String, sshKey: URL) {
    val localshell = SSH(sshIp, 22, "root", sshKey)
    println(Shell.Plain(localshell).exec("ping 192.168.168.1 -c 1"))
    Shell.Plain(localshell).exec("exit")
}