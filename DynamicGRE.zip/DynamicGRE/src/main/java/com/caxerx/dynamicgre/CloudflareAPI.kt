package com.caxerx.dynamicgre

import khttp.get
import khttp.put
import khttp.responses.Response
import org.json.JSONObject

/**
 * Created by caxerx on 2017/6/4.
 */
class CloudflareAPI {
    //api -> 3ed7c6f252cbe14aec40b780781ac2fb9836b
    //caxerx.com -> b262f233872e6634140633c974823a3b
    //zones/b262f233872e6634140633c974823a3b/dns_records?name=ddns.caxerx.com
    val apiBaseUrl: String = "https://api.cloudflare.com/client/v4/"
    val apiKey: String
    val zoneKey: String
    val header: HashMap<String, String>

    constructor(apiKey: String, email: String, zoneKey: String) {
        this.apiKey = apiKey
        this.zoneKey = zoneKey
        this.header = HashMap<String, String>()
        header.put("X-Auth-Key", apiKey)
        header.put("X-Auth-Email", email)
        header.put("Content-Type", "application/json")
    }

    fun getRecordKey(recordName: String): String {
        return getRecord(recordName).getString("id")
    }

    fun getRecordContent(recordName: String): String {
        return getRecord(recordName).getString("content")
    }

    fun getRecord(recordName: String): JSONObject {
        val params: HashMap<String, String> = HashMap()
        params.put("name", recordName)
        var requestResult = requestApi("zones/$zoneKey/dns_records", params)
        var result = requestResult.jsonObject.getJSONArray("result")
        if (result.length() > 0) {
            return result.getJSONObject(0)
        } else {
            throw Exception("No record found")
        }
    }


    fun requestApi(url: String, params: HashMap<String, String>): Response {
        var requestResult = get("$apiBaseUrl$url", header, params)
        if (requestResult.jsonObject.getBoolean("success")) {
            return requestResult
        } else {
            throw Exception(requestResult.jsonObject.getJSONArray("errors").getJSONObject(0).getString("message"))
        }
    }

    fun editRecord(recordId: String, type: String, name: String, content: String): Boolean {
        val params: HashMap<String, String> = HashMap()
        params.put("type", type)
        params.put("name", name)
        params.put("content", content)
        return get("https://api.cloudflare.com/client/v4/zones/$zoneKey/dns_records/$recordId", header, params).jsonObject.getBoolean("success")
    }

    fun editRecordByName(recordName: String, type: String, content: String): Boolean {
        val params: JSONObject = JSONObject()
        params.put("type", type)
        params.put("name", recordName)
        params.put("content", content)
        var recordId = getRecordKey(recordName)
        return put(url = "https://api.cloudflare.com/client/v4/zones/$zoneKey/dns_records/$recordId", headers = header, json = params).jsonObject.getBoolean("success")
    }

}

